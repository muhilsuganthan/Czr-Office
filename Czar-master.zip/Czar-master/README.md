# Czar
Czar is an Office automation tool developed in php. It is currently under active development.
Changes made and new features added.
App is being tested on Heroku cloud platform.
