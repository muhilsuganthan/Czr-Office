<?php
/* 
 ** **************************Czar V 0.4*********************************
 ** *********************************************************************
 ** Common Navigation Bar
 ** Important dependancy for most/all Admin pages
 **
 ** Designer: Muhil Suganthan - muhilsuganthan@yourtpdc.com
 ** Last major Change: April 28,2016
 ** ********************************************************************
 ** *************************Powered By TPDC****************************
*/
?>
<nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown profile-element"> <span>
                            <img alt="image" class="img-circle" src="../img/profile_small.jpg" />
                             </span>
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold">Manager</strong>
                             </span> <span class="text-muted text-xs block">Art Director <b class="caret"></b></span> </span> </a>
                        <ul class="dropdown-menu animated fadeInRight m-t-xs">
                            <li><a href="Profile.php">Profile</a></li>
                            <li><a href="mail.php">Mailbox</a></li>
                            <li class="divider"></li>
                            <li><a href="../config/logout.php">Logout</a></li>
                        </ul>
                    </div>
                    <div class="logo-element">
                        Czar
                    </div>
                </li>
                <li>
                
                    <a href="../addclass.php"><i class="fa fa-th-large"></i> <span class="nav-label">Manage Teams</span></a>
                    
                </li>
                               
                <li>
                    <a href="Manage-Categories.php"><i class="fa fa-book"></i> <span class="nav-label">Manage Categories</a>
                </li>
                       
                
                <li>
                    <a href="#"><i class="fa fa-mortar-board"></i> <span class="nav-label">Tickets</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li><a href="Create-Tickets.php">Create Tickets</a></li>
                        <li><a href="tickets.php">Manage Tickets</a></li>
                        
                       
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-edit"></i> <span class="nav-label">Announcements</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">                       
                        <li><a href="announcement.php">Meetings</a></li>
                        <li><a href="mail.php">Messages</a></li>
                       
                    </ul>
                </li>
                
                 
                <li>
                    <a href="#"><i class="fa fa-users"></i> <span class="nav-label">Staff details</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li><a href="../addstaff.php">Staff Registration</a></li>
                        <li><a href="../staffrec.php">Staff Records</a></li>
                        <li><a href="../staffattenedit.php">Staff Attendance Entry</a></li>
                       
                         <li><a href="../staffattend.php">Attendance Report</a></li>
                       
                    </ul>
                </li>
                 <li>
                    <a href="#"><i class="fa fa-frown-o"></i> <span class="nav-label">Discard/Rework</span> </a>
                </li>
                <li>
                    <a href="#"><i class="fa fa-line-chart"></i> <span class="nav-label">Employee Rating</span> </a>
                </li>
                 
                 <li>
                    <a href="../widgets.html"><i class="fa fa-cogs"></i> <span class="nav-label">Change Password</span> </a>
                </li>
               
     </ul>
     </div>
     </nav>
