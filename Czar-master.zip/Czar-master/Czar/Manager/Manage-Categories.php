<?php
  	/* 
     ** **************************Czar V 0.4*********************************
     ** *********************************************************************
     ** Manage-Categories.php contains all categories that are used in the
     ** requirement pool
     ** Depends on
     ** 1. config/managervalidate.php for authorization
     ** 2. config/config.php for connectivity
     ** 3. modal.php for modal forms
     ** 4. navbar.php
     ** 5. navbar1.php
     ** 6. breadcrumb.php
     ** 7. footer.php
     **
     ** Designer & Programmer: Siva Subramanian-sivasubramanian@yourtpdc.com
     ** Last major Change: April 28,2016
     ** *********************************************************************
     ** *************************Powered By TPDC*****************************
    */
    require_once '../config/managervalidate.php';
    require_once '../libs/definitions.php';
    require_once 'modal.php';
    require_once '../libs/dboperations.php';
    $page_title="Categories";
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>:: CZAR MANAGER ::</title>
   
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="../font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Data Tables -->
    <link href="../css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
    <link href="../css/plugins/dataTables/dataTables.responsive.css" rel="stylesheet">
    <link href="../css/plugins/dataTables/dataTables.tableTools.min.css" rel="stylesheet">


    <!-- Toastr style -->
    <link href="../css/plugins/toastr/toastr.min.css" rel="stylesheet">

    <!-- Gritter -->
    <link href="../js/plugins/gritter/jquery.gritter.css" rel="stylesheet">

    <link href="../css/animate.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">


</head>

<body>

    <div id="wrapper">
		<?php require_once 'navbar.php'; ?>
    <?php require_once 'navbar1.php'; ?>
    <?php require_once 'breadcrumb.php'; ?>
           
        <div class="wrapper wrapper-content animated fadeInRight">    
       <!--------Content Starting------ -->
       <div class="row">

       <!-- Content Heading -->
          <div class="col-lg-12">
            <div class="ibox float-e-margins">
              <div class="ibox-content ibox-heading">
                <div class="text-center">
                  <a data-toggle="modal" class="btn btn-primary" href="#categories">Click here to add value to a Category</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Content Heading Ends -->
        
        <!-- Category Tables -->
        <div class="row">


          <div class="col-lg-4">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <h5>Order Types</h5>
                <div class="ibox-tools">
                  <a class="collapse-link">
                  <i class="fa fa-chevron-up"></i>
                  </a>
                </div>
              </div>
            

              <div class="ibox-content">
                <table class="table table-striped table-bordered table-hover dataTables-example" >
                  <tbody>
                  <?php 
                    $pickorder=mysqli_query($con,"SELECT order_type from cz_order_types Where order_type!=''");
                    while($row=mysqli_fetch_array($pickorder))
                    {
                      if($row[0]!=""){
                        $order_types=$row[0];
                      }
                  ?>
                  <tr class="gradeX">
                    <td><?php echo $order_types; ?></td>
                  </tr>
                  <?php 
                    }
                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div class="col-lg-4">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <h5>Job Types</h5>
                <div class="ibox-tools">
                  <a class="collapse-link">
                  <i class="fa fa-chevron-up"></i>
                  </a>
                </div>
              </div>
            

              <div class="ibox-content">
                <table class="table table-striped table-bordered table-hover dataTables-example" >
                  <tbody>
                  <?php 
                    $pickjobtype=mysqli_query($con,"SELECT work_type from cz_order_types Where work_type!=''");
                    while($row=mysqli_fetch_array($pickjobtype))
                    {
                      if($row[0]!=""){
                        $work_types=$row[0];
                      }
                  ?>
                  <tr class="gradeX">
                    <td><?php echo $work_types; ?></td>
                  </tr>
                  <?php 
                    }
                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div class="col-lg-4">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <h5>Sizes</h5>
                <div class="ibox-tools">
                  <a class="collapse-link">
                  <i class="fa fa-chevron-up"></i>
                  </a>
                </div>
              </div>
            

              <div class="ibox-content">
                <table class="table table-striped table-bordered table-hover dataTables-example" >
                  <tbody>
                  <?php 
                    $picksizes=mysqli_query($con,"SELECT size_type from cz_order_types Where size_type!=''");
                    while($row=mysqli_fetch_array($picksizes))
                    {
                      if($row[0]!=""){
                        $sizes=$row[0];
                      }
                  ?>
                  <tr class="gradeX">
                    <td><?php echo $sizes; ?></td>
                  </tr>
                  <?php 
                    }
                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          </div>

        <div class="row">
          <div class="col-lg-6">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <h5>Color Types</h5>
                <div class="ibox-tools">
                  <a class="collapse-link">
                  <i class="fa fa-chevron-up"></i>
                  </a>
                </div>
              </div>
            

              <div class="ibox-content">
                <table class="table table-striped table-bordered table-hover dataTables-example" >
                  <tbody>
                  <?php 
                    $pickcolor=mysqli_query($con,"SELECT color_type from cz_order_types Where color_type!=''");
                    while($row=mysqli_fetch_array($pickcolor))
                    {
                      if($row[0]!=""){
                        $color_types=$row[0];
                      }
                  ?>
                  <tr class="gradeX">
                    <td><?php echo $color_types; ?></td>
                  </tr>
                  <?php 
                    }
                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>




          <div class="col-lg-6">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <h5>Output file Types</h5>
                <div class="ibox-tools">
                  <a class="collapse-link">
                  <i class="fa fa-chevron-up"></i>
                  </a>
                </div>
              </div>
            

              <div class="ibox-content">
                <table class="table table-striped table-bordered table-hover dataTables-example" >
                  <tbody>
                  <?php 
                    $pickoutputtype=mysqli_query($con,"SELECT output_type from cz_order_types Where output_type!=''");
                    while($row=mysqli_fetch_array($pickoutputtype))
                    {
                      if($row[0]!=""){
                        $output_types=$row[0];
                      }
                  ?>
                  <tr class="gradeX">
                    <td><?php echo $output_types; ?></td>
                  </tr>
                  <?php 
                    }
                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>


        </div>


        <!-- Category Table Ends -->


 
        </div>
       <!--------Content Ends here----- -->

        <?php require_once 'footer.php'; ?>>

        </div>
        </div>
 
    <!-- Mainly scripts -->
    <script src="../js/jquery-2.1.1.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="../js/inspinia.js"></script>
    <script src="../js/plugins/pace/pace.min.js"></script>
    <script src="../js/plugins/toastr/toastr.min.js"></script>
     <!-- Custom and plugin javascript -->
    <script src="../js/inspinia.js"></script>
    <script src="../js/plugins/pace/pace.min.js"></script>


    <!-- Data Tables -->
    <script src="../js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="../js/plugins/dataTables/dataTables.bootstrap.js"></script>
    <script src="../js/plugins/dataTables/dataTables.responsive.js"></script>
    <script src="../js/plugins/dataTables/dataTables.tableTools.min.js"></script>


    <!-- jQuery UI -->
    <script src="../js/plugins/jquery-ui/jquery-ui.min.js"></script>

    <!-- GITTER -->
    <script src="../js/plugins/gritter/jquery.gritter.min.js"></script>

    <!-- Sparkline -->
    <script src="../js/plugins/sparkline/jquery.sparkline.min.js"></script>

  <script>
        $(document).ready(function() {
            $('.dataTables-example').dataTable({
                responsive: true,
                "dom": 'T<"clear">lfrtip',
                "tableTools": {
                    "sSwfPath": "../js/plugins/dataTables/swf/copy_csv_xls_pdf.swf"
                }
                
            });

            /* Init DataTables */
            var oTable = $('#editable').dataTable();

            /* Apply the jEditable handlers to the table */
            oTable.$('td').editable( '../example_ajax.php', {
                "callback": function( sValue, y ) {
                    var aPos = oTable.fnGetPosition( this );
                    oTable.fnUpdate( sValue, aPos[0], aPos[1] );
                },
                "submitdata": function ( value, settings ) {
                    return {
                        "row_id": this.parentNode.getAttribute('id'),
                        "column": oTable.fnGetPosition( this )[2]
                    };
                },

                "width": "90%",
                "height": "100%"
            } );

          });

</body>

</html>

<?php

  // Executes on submit
  if(isset($_POST['submit'])){
    $type=$_POST["type"];
    $value=$_POST["value"];

    // Find column value

    if($type=="Order Types"){
      $sql=mysqli_query($con,"INSERT INTO cz_order_types(cz_order_types) values('$value')");
    }
    elseif($type=="Job Types"){
      $sql=mysqli_query($con,"INSERT INTO cz_order_types(work_type) values('$value')");
    }
    elseif($type=="Sizes"){
      $sql=mysqli_query($con,"INSERT INTO cz_order_types(size_type) values('$value')");
    }
    elseif($type=="Color Types"){
      $sql=mysqli_query($con,"INSERT INTO cz_order_types(color_type) values('$value')");
    }
    elseif($type=="Output file Types"){
      $sql=mysqli_query($con,"INSERT INTO cz_order_types(output_type) values('$value')");
    }
    // insetring into database
    if ($sql)
    {
      // Notification on success
?>
      <script>
            $(document).ready(function() {
            setTimeout(function() {
                toastr.options = {
                    closeButton: true,
                    progressBar: true,
                    showMethod: 'slideDown',
                    timeOut: 4000
                };
                toastr.info('Created new post', 'Success');

            }, 1300);
            
        });
        </script>
    <?php
    
  }
    else 
    {
      // Notification on failure
      ?>
      <script>
            $(document).ready(function() {
            setTimeout(function() {
                toastr.options = {
                    closeButton: true,
                    progressBar: true,
                    showMethod: 'slideDown',
                    timeOut: 4000
                };
                toastr.error('Unexpected error occured', 'Error');

            }, 1300);
            
        });
        </script>
    <?php
      
    }
  }


