       <?php
         include("../config/managervalidate.php");
         include("../config/config.php");
         ?>          
         <div class="col-lg-4">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <div class="ibox-tools">
                  <a class="collapse-link">
                  <i class="fa fa-chevron-up"></i>
                  </a>
                </div>
                <h5>Customer details</h5>
              </div>
              <div class="ibox-content">
                <h6><strong>Enter Customer Details</strong></h6>
                <label class="control-label">Customer  Name</label>
                <div class="form-group"><input type="text" name="customer_name" class="form-control"></div>
                <label class="control-label">Email ID</label>
                <div class="form-group"><input type="text" name="customer_email" class="form-control"></div>
                <label class="control-label">Mobile Number</label>
                <div class="form-group"><input type="text" name="customer_obile" class="form-control"></div>
                <label class="control-label">Website</label>
                <div class="form-group"><input type="text" name="customer_website" class="form-control"></div>
              </div>
            </div>
          </div>

          <div class="col-lg-4">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <div class="ibox-tools">
                  <a class="collapse-link">
                  <i class="fa fa-chevron-up"></i>
                  </a>
                </div>
                <h5>Order details</h5>
              </div>
              <div class="ibox-content">
                <label class="control-label">Order type</label>
                <div class="form-group"><select class="form-control m-b" name="order_type">
                <?php 
                        $pickorder=mysqli_query($con,"SELECT order_type from cz_order_types Where order_type!=''");
                    while($row=mysqli_fetch_array($pickorder))
                    {
                      if($row[0]!=""){
                        $order_types=$row[0];
                            
                        ?>
            <option value="<?php echo $order_types; ?>"><?php echo $order_types; ?></option>
                        <?php } }?>
                        </select></div>
                <label class="control-label">Job Type</label>
                <div class="form-group"><select class="form-control m-b" name="job_type">
                <?php 
                    $pickjobtype=mysqli_query($con,"SELECT work_type from cz_order_types Where work_type!=''");
                    while($row=mysqli_fetch_array($pickjobtype))
                    {
                      if($row[0]!=""){
                        $work_types=$row[0];
                  ?>
            <option value="<?php echo $work_types; ?>"><?php echo $work_types; ?></option>
                        <?php }} ?>
                        </select></div><hr>
                <label class="control-label">Size</label>
                <div class="form-group"><select class="form-control m-b" name="sizes">
                <?php 
                    $picksizes=mysqli_query($con,"SELECT size_type from cz_order_types Where size_type!=''");
                    while($row=mysqli_fetch_array($picksizes))
                    {
                      if($row[0]!=""){
                        $sizes=$row[0];
                  ?>
            <option value="<?php echo $sizes; ?>"><?php echo $sizes; ?></option>
                        <?php } }?>
                        </select></div>
                <div class="col-sm-6"><input type="text" placeholder="Width" name="width" class="form-control"></div>
                <div class="col-sm-6"><input type="text" name="height" placeholder="Height" class="form-control"></div>
                <hr><hr>
                <label class="control-label">Color Type</label>
                <div class="form-group"><select data-placeholder="Color Type" class="form-control m-b" name="color_type">
                <?php 
                    $pickcolor=mysqli_query($con,"SELECT color_type from cz_order_types Where color_type!=''");
                    while($row=mysqli_fetch_array($pickcolor))
                    {
                      if($row[0]!=""){
                        $color_types=$row[0];
                  ?>
            <option value="<?php echo $color_types; ?>"><?php echo $color_types; ?></option>
                        <?php } }?>
                        </select></div>
              </div>
            </div>
          </div>

          <div class="col-lg-4">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <div class="ibox-tools">
                  <a class="collapse-link">
                  <i class="fa fa-chevron-up"></i>
                  </a>
                </div>
                <h5>Project Details</h5>
              </div>
              <div class="ibox-content">
                <label class="control-label">Additional Informations</label>
                <div class="form-group"><textarea class="form-group" name="additional-info"></textarea> </div>
                <label class="control-label">Delivery options</label>
                <div class="form-group"><select data-placeholder="Color Type" class="form-control m-b" name="output_type">
                <?php 
                    $pickoutputtype=mysqli_query($con,"SELECT output_type from cz_order_types Where output_type!=''");
                    while($row=mysqli_fetch_array($pickoutputtype))
                    {
                      if($row[0]!=""){
                        $output_types=$row[0];
                  ?>
            <option value="<?php echo $output_types; ?>"><?php echo $output_types; ?></option>
                        <?php } }?>
                        </select></div>
                        <label class="control-label">Expected date</label>
                        <div class="input-group date">
            <span class="input-group-addon"><i class="fa fa-calendar"></i></span><input type="text" name="delivery_date" class="form-control" >
          </div>
              </div>
            </div>
          </div>

           <div class="col-lg-4">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <div class="ibox-tools">
                  <a class="collapse-link">
                  <i class="fa fa-chevron-up"></i>
                  </a>
                </div>
                <h5>Submit</h5>
              </div>
              <div class="ibox-content">
                <div class="text-center">
                <button class="btn btn-success btn-outline" type="submit" name="submit"><strong>Submit</strong></button></div>
              </div>
            </div>
          </div>
          

<script src="../js/jquery-2.1.1.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="../js/inspinia.js"></script>
    <script src="../js/plugins/pace/pace.min.js"></script>
    <script src="../js/plugins/toastr/toastr.min.js"></script>
     <!-- Custom and plugin javascript -->
    <script src="../js/inspinia.js"></script>
    <!-- Steps -->
    <script src="../js/plugins/staps/jquery.steps.min.js"></script>
<!-- Date picker -->
    <script src="../js/plugins/datapicker/bootstrap-datepicker.js"></script>


    <!-- Jquery Validate -->
    <script src="../js/plugins/validate/jquery.validate.min.js"></script>
<script>
        $(document).ready(function() {
            $('.dataTables-example').dataTable({
                responsive: true,
                "dom": 'T<"clear">lfrtip',
                "tableTools": {
                    "sSwfPath": "../js/plugins/dataTables/swf/copy_csv_xls_pdf.swf"
                }
                
            });

            /* Init DataTables */
            var oTable = $('#editable').dataTable();

            /* Apply the jEditable handlers to the table */
            oTable.$('td').editable( '../example_ajax.php', {
                "callback": function( sValue, y ) {
                    var aPos = oTable.fnGetPosition( this );
                    oTable.fnUpdate( sValue, aPos[0], aPos[1] );
                },
                "submitdata": function ( value, settings ) {
                    return {
                        "row_id": this.parentNode.getAttribute('id'),
                        "column": oTable.fnGetPosition( this )[2]
                    };
                },

                "width": "90%",
                "height": "100%"
            } );

          });
</script>
<script>
       
            $('#data_1 .input-group.date').datepicker({
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true
            });

            $('#data_2 .input-group.date').datepicker({
                startView: 1,
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true
            });

            $('#data_3 .input-group.date').datepicker({
                startView: 2,
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true
            });

            $('#data_4 .input-group.date').datepicker({
                minViewMode: 1,
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true,
                todayHighlight: true
            });

            $('#data_5 .input-daterange').datepicker({
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true
            });
    </script>
