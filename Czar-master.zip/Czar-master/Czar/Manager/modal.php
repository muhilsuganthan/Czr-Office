<?php
/* 
 ** **************************Czar V 0.4*********************************
 ** *********************************************************************
 ** modal.php is a common modal-dialog for all pages
 ** contains most of the modal-form details
 ** Important dependancy for many Admin pages
 ** Depends on config.php for some data
 **
 ** Designer: Muhil Suganthan - muhilsuganthan@yourtpdc.com
 ** Design modifications  - Siva Subramanian
 ** Backend programmer: Siva Subramanian - sivasubramanian@yourtpdc.com
 ** Last major Change: April 28,2016
 ** ********************************************************************
 ** *************************Powered By TPDC****************************
*/
?>

                              
<!-- Manage Teams -->

<div id="categories" class="modal fade" aria-hidden="true">
  <div class="modal-dialog">
   <div class="modal-content">
    <div class="modal-body">
      <div class="row">
        <!-- Column 1 -->
        <div class="col-sm-6 b-r"><h3 class="m-t-none m-b">ADD VALUE TO A CATEGORY</h3>
        <form role="form" action="" method="POST">
        <div class="form-group">
            <label>Category Type</label>
            <div class="input-group">
                <select class="form-control m-b" name="type">
                    <option value="">Select</option>
                    <option value="Order Types">Order Types</option>
                    <option value="Job Types">Job Types</option>
                    <option value="Sizes">Sizes</option>
                    <option value="Color Types">Color Types</option>
                    <option value="Output file Types">Output file Types</option>
                </select>
            </div>
        </div>
        </div>
        <!-- Column 1 ends -->

        <!-- Column 2 -->
        <div class="col-sm-6 b-r">  
            <div class="form-group"><label>Value</label><input type="text" class="form-control m-b" name="value" required="">
            </div> 
            <div>
                <button class="btn btn-sm btn-primary pull-right m-t-n-xs" type="submit" name="submit"><strong>CREATE</strong></button>
            </div>
        </div>
        <!-- Column 2 ends -->
        </form>
      </div>
     </div>
    </div>
   </div>
  </div>
 </div>