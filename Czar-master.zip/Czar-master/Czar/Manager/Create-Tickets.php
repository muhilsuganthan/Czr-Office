<?php
  	/* 
     ** **************************Czar V 0.4*********************************
     ** *********************************************************************
     ** Create-Tickets.php contains all categories that are used in the
     ** requirement pool
     ** Depends on
     ** 1. config/managervalidate.php for authorization
     ** 2. config/config.php for connectivity
     ** 3. modal.php for modal forms
     ** 4. navbar.php
     ** 5. navbar1.php
     ** 6. breadcrumb.php
     ** 7. footer.php
     **
     ** Designer & Programmer: Siva Subramanian-sivasubramanian@yourtpdc.com
     ** Last major Change: April 28,2016
     ** *********************************************************************
     ** *************************Powered By TPDC*****************************
    */
  	require_once '../config/managervalidate.php';
    require_once '../libs/definitions.php';
    require_once 'modal.php';
    require_once '../libs/dboperations.php';
    $page_title="Create Tickets";
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>:: CZAR MANAGER ::</title>
   
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="../font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="../css/plugins/steps/jquery.steps.css" rel="stylesheet">

    <!-- Toastr style -->
    <link href="../css/plugins/toastr/toastr.min.css" rel="stylesheet">

    <link href="../css/animate.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">


</head>

<body>

    <div id="wrapper">
    <!-- MAIN WRAPPER STARTS -->
    <?php require_once 'navbar.php'; ?>
    <?php require_once 'navbar1.php'; ?>
    <?php require_once 'breadcrumb.php'; ?>
    
           
      <div class="wrapper wrapper-content animated fadeInRight">    
       <!--------Content Starting------ -->
      <form action="" method="POST">
        <div id="output1" class="row">
          <div class="col-lg-4">
            <div class="ibox float-e-margins">
              <div class="ibox-title">
                <div class="ibox-tools">
                  <a class="collapse-link">
                  <i class="fa fa-chevron-up"></i>
                  </a>
                </div>
                <h5>Customer details</h5>
              </div>
              <div id ="output1"class="ibox-content">
                <h6><strong>For a returning customer please enter customer ID</strong></h6>
                <!--<select class="form-control m-b" name="customer" onChange="showform(this);">
                  <option value"">------</option>
                  <option value="returning">Returning</option>
                  <option value="new">New Customer</option>
                </select>-->
                
              </div>
            </div>
          </div>

         

        </div>
      </form>
        
                  


       <!--------Content Ends here----- -->
      </div>
        <?php require_once 'footer.php'; ?>
    <!-- MAIN WRAPPPER ENDS -->
    </div>
    </div>
 
    <!-- Mainly scripts -->
    <script src="../js/jquery-2.1.1.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="../js/inspinia.js"></script>
    <script src="../js/plugins/pace/pace.min.js"></script>
    <script src="../js/plugins/toastr/toastr.min.js"></script>
     <!-- Custom and plugin javascript -->
    <script src="../js/inspinia.js"></script>
    <!-- Steps -->
    <script src="../js/plugins/staps/jquery.steps.min.js"></script>

    <!-- Jquery Validate -->
    <script src="../js/plugins/validate/jquery.validate.min.js"></script>
        <script src="../js/plugins/datapicker/bootstrap-datepicker.js"></script>

<script>
function showform(sel) {
  var customer = sel.options[sel.selectedIndex].value;  
  $("#output1").html( "" );
  
  if (customer.length > 0 ) { 

  if(customer=="new"){
   $.ajax({
      type: "POST",
      url: "load.php",
      //data: "class_id="+class_id,
      cache: false,
      beforeSend: function () { 
        $('#output1').html('<center><img src="squares.gif" alt="Loading..."  width="150" height="150"></center>');
      },
      success: function(html) {    
        $("#output1").html( html );
      }
    });
}
if(customer=="returning"){
   $.ajax({
      type: "POST",
      url: "load2.php",
      //data: "class_id="+class_id,
      cache: false,
      beforeSend: function () { 
        $('#output1').html('<center><img src="squares.gif" alt="Loading..."  width="150" height="150"></center>');
      },
      success: function(html) {    
        $("#output1").html( html );
      }
    });
}
  } 
}
</script>

    
     <script>
        $(document).ready(function() {
            $('.dataTables-example').dataTable({
                responsive: true,
                "dom": 'T<"clear">lfrtip',
                "tableTools": {
                    "sSwfPath": "../js/plugins/dataTables/swf/copy_csv_xls_pdf.swf"
                }
                
            });

            /* Init DataTables */
            var oTable = $('#editable').dataTable();

            /* Apply the jEditable handlers to the table */
            oTable.$('td').editable( '../example_ajax.php', {
                "callback": function( sValue, y ) {
                    var aPos = oTable.fnGetPosition( this );
                    oTable.fnUpdate( sValue, aPos[0], aPos[1] );
                },
                "submitdata": function ( value, settings ) {
                    return {
                        "row_id": this.parentNode.getAttribute('id'),
                        "column": oTable.fnGetPosition( this )[2]
                    };
                },

                "width": "90%",
                "height": "100%"
            } );

          });
</script>
<script>
       
            $('#data_1 .input-group.date').datepicker({
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true
            });

            $('#data_2 .input-group.date').datepicker({
                startView: 1,
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true
            });

            $('#data_3 .input-group.date').datepicker({
                startView: 2,
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true
            });

            $('#data_4 .input-group.date').datepicker({
                minViewMode: 1,
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true,
                todayHighlight: true
            });

            $('#data_5 .input-daterange').datepicker({
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true
            });
    </script>

</body>

</html>
