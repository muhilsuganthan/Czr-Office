<?php
/* 
 ** **************************Czar V 0.4*********************************
 ** *********************************************************************
 ** Contains Footer information for all pages
 **
 ** Designer: Muhil Suganthan - muhilsuganthan@yourtpdc.com
 ** Backend programmer: Siva Subramanian - sivasubramanian@yourtpdc.com
 ** Last major Change: April 28,2016
 ** ********************************************************************
 ** *************************Powered By TPDC****************************
*/
?>

<div class="footer" align="center">
           
            <div>
                <strong>Powered By</strong> TPDC
            </div>
        </div>
