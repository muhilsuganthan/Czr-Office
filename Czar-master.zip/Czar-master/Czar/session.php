<?php

session_start();
if (isset($_SESSION['user'])) {
    if (($_SESSION['user'] != "") && ($_SESSION['privilege'] != "")) {
        if ($_SESSION['privilege'] == "2") {
            header('Location: Admin/index.php');
        } elseif ($_SESSION['privilege'] == "1") {
            header('Location: Manager/index.php');
        } elseif ($_SESSION['privilege'] == "0") {
            header('Location: Employee/index.php');
        }
    } else {
        
    }
}