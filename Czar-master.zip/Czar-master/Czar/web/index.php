<?php
  	/* 
     ** **************************Czar V 0.4*********************************
     ** *********************************************************************
     ** Create-Tickets.php contains all categories that are used in the
     ** requirement pool
     ** Depends on
     ** 1. config/managervalidate.php for authorization
     ** 2. config/config.php for connectivity
     ** 3. modal.php for modal forms
     ** 4. navbar.php
     ** 5. navbar1.php
     ** 6. breadcrumb.php
     ** 7. footer.php
     **
     ** Designer & Programmer: Siva Subramanian-sivasubramanian@yourtpdc.com
     ** Last major Change: April 28,2016
     ** *********************************************************************
     ** *************************Powered By TPDC*****************************
    */
  	require_once '../config/managervalidate.php';
    require_once '../libs/definitions.php';
    //require_once 'modal.php';
    require_once '../libs/dboperations.php';
    $page_title="Create Tickets";
?>

<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>:: CZAR MANAGER ::</title>

    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="../font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Toastr style -->
    <link href="../css/plugins/toastr/toastr.min.css" rel="stylesheet">

    <!-- Gritter -->
    <link href="../js/plugins/gritter/jquery.gritter.css" rel="stylesheet">

    <link href="../css/animate.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">


</head>

<body>

    <div id="wrapper">

    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown profile-element"> <span>
                            <img alt="image" class="img-circle" src="../img/profile_small.jpg" />
                             </span>
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold">Manager</strong>
                             </span> <span class="text-muted text-xs block">Art Director <b class="caret"></b></span> </span> </a>
                        <ul class="dropdown-menu animated fadeInRight m-t-xs">
                            <li><a href="../profile.html">Profile</a></li>
                            <li><a href="../contacts.html">Contacts</a></li>
                            <li><a href="../mailbox.html">Mailbox</a></li>
                            <li class="divider"></li>
                            <li><a href="../login.html">Logout</a></li>
                        </ul>
                    </div>
                    <div class="logo-element">
                        Czar
                    </div>
                </li>
                <li>
                
                    <a href="../addclass.php"><i class="fa fa-th-large"></i> <span class="nav-label">Create Teams</span></a>
                    
                </li>
                               
                <li>
                    <a href="../addsubject.php"><i class="fa fa-book"></i> <span class="nav-label">Create New Categories</a>
                </li>
                       
                
                <li>
                    <a href="#"><i class="fa fa-mortar-board"></i> <span class="nav-label">Tasks</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li><a href="../addstud.php">Manage Tasks</a></li>
                        <li><a href="../sturec.php">Authorize Tasks</a></li>
                        <li><a href="../sturec.php">Assign Task</a></li>
                        
                       
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="fa fa-edit"></i> <span class="nav-label">Announcements</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">                       
                        <li><a href="../addexams.php">Meetings</a></li>
                        <li><a href="../addexams.php">Messages</a></li>
                       
                    </ul>
                </li>
                
                 
                <li>
                    <a href="#"><i class="fa fa-users"></i> <span class="nav-label">Staff details</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li><a href="../addstaff.php">Staff Registration</a></li>
                        <li><a href="../staffrec.php">Staff Records</a></li>
                        <li><a href="../staffattenedit.php">Staff Attendance Entry</a></li>
                       
                         <li><a href="../staffattend.php">Attendance Report</a></li>
                       
                    </ul>
                </li>
                 <li>
                    <a href="#"><i class="fa fa-frown-o"></i> <span class="nav-label">Discard/Rework</span> </a>
                </li>
                <li>
                    <a href="#"><i class="fa fa-line-chart"></i> <span class="nav-label">Employee Rating</span> </a>
                </li>
                 
                 <li>
                    <a href="../widgets.html"><i class="fa fa-cogs"></i> <span class="nav-label">Change Password</span> </a>
                </li>
               
     </ul>
     </div>
     </nav>

        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
        <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
               
            </div>

            <ul class="nav navbar-top-links navbar-right">
                <li>
                    <span class="m-r-sm text-muted welcome-message">Czar</span>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
                        <i class="fa fa-envelope"></i>  <span class="label label-warning">16</span>
                    </a>
                    <ul class="dropdown-menu dropdown-messages">
                        <li>
                            <div class="dropdown-messages-box">
                                <a href="../profile.html" class="pull-left">
                                    <img alt="image" class="img-circle" src="../img/a7.jpg">
                                </a>
                                <div class="media-body">
                                    <small class="pull-right">46h ago</small>
                                    <strong>Mike Loreipsum</strong> started following <strong>Monica Smith</strong>. <br>
                                    <small class="text-muted">3 days ago at 7:58 pm - 10.06.2014</small>
                                </div>
                            </div>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <div class="dropdown-messages-box">
                                <a href="../profile.html" class="pull-left">
                                    <img alt="image" class="img-circle" src="../img/a4.jpg">
                                </a>
                                <div class="media-body ">
                                    <small class="pull-right text-navy">5h ago</small>
                                    <strong>Chris Johnatan Overtunk</strong> started following <strong>Monica Smith</strong>. <br>
                                    <small class="text-muted">Yesterday 1:21 pm - 11.06.2014</small>
                                </div>
                            </div>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <div class="dropdown-messages-box">
                                <a href="../profile.html" class="pull-left">
                                    <img alt="image" class="img-circle" src="../img/profile.jpg">
                                </a>
                                <div class="media-body ">
                                    <small class="pull-right">23h ago</small>
                                    <strong>Monica Smith</strong> love <strong>Kim Smith</strong>. <br>
                                    <small class="text-muted">2 days ago at 2:30 am - 11.06.2014</small>
                                </div>
                            </div>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <div class="text-center link-block">
                                <a href="../mailbox.html">
                                    <i class="fa fa-envelope"></i> <strong>Read All Messages</strong>
                                </a>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
                        <i class="fa fa-bell"></i>  <span class="label label-primary">8</span>
                    </a>
                    <ul class="dropdown-menu dropdown-alerts">
                        <li>
                            <a href="../mailbox.html">
                                <div>
                                    <i class="fa fa-envelope fa-fw"></i> You have 16 messages
                                    <span class="pull-right text-muted small">4 minutes ago</span>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="../profile.html">
                                <div>
                                    <i class="fa fa-twitter fa-fw"></i> 3 New Followers
                                    <span class="pull-right text-muted small">12 minutes ago</span>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="../grid_options.html">
                                <div>
                                    <i class="fa fa-upload fa-fw"></i> Server Rebooted
                                    <span class="pull-right text-muted small">4 minutes ago</span>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <div class="text-center link-block">
                                <a href="../notifications.html">
                                    <strong>See All Alerts</strong>
                                    <i class="fa fa-angle-right"></i>
                                </a>
                            </div>
                        </li>
                    </ul>
                </li>


                <li>
                    <a href="../login.html">
                        <i class="fa fa-sign-out"></i> Log out
                    </a>
                </li>
            </ul>


        </nav>
        </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Manager Panel</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="../index.html">Home</a>
                        </li>
                        <li>
                            <a>Manager panel</a>
                        </li>
                        <li class="active">
                            <strong>Dashboard</strong>
                        </li>
                    </ol>
                </div>
                
            </div>
        
        <div class="footer" align="center">
           
            <div>
                <strong>Copyright</strong> TPDC &copy; 2015-2016
            </div>
        </div>

        </div>
        </div>


    <!-- Mainly scripts -->
    <script src="../js/jquery-2.1.1.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="../js/inspinia.js"></script>
    <script src="../js/plugins/pace/pace.min.js"></script>
<script src="../js/plugins/toastr/toastr.min.js"></script>
     <!-- Custom and plugin javascript -->
    <script src="../js/inspinia.js"></script>
    <script src="../js/plugins/pace/pace.min.js"></script>

    <!-- jQuery UI -->
    <script src="../js/plugins/jquery-ui/jquery-ui.min.js"></script>

    <!-- GITTER -->
    <script src="../js/plugins/gritter/jquery.gritter.min.js"></script>

    <!-- Sparkline -->
    <script src="../js/plugins/sparkline/jquery.sparkline.min.js"></script>


<script>
        $(document).ready(function() {
            setTimeout(function() {
                toastr.options = {
                    closeButton: true,
                    progressBar: true,
                    showMethod: 'slideDown',
                    timeOut: 4000
                };
                toastr.success('Office Automation System', 'Welcome to Czar');

            }, 1300);
            
        });
    </script>
    <script src="../js/plugins/iCheck/icheck.min.js"></script>
        <script>
            $(document).ready(function () {
                $('.i-checks').iCheck({
                    checkboxClass: 'icheckbox_square-green',
                    radioClass: 'iradio_square-green',
                });
            });
        </script>


</body>

</html>
