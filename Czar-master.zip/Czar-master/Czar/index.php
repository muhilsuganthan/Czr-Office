<?php
/* 
 ** **************************Czar V 0.4*********************************
 ** *********************************************************************
 ** Index.php -- This is a common login page for users of all previleges
 ** Users credentials will be checked and  a new session is created
 ** and redirected to result1.php
 ** Depends on config/config.php and session.php
 **
 ** Designer: Muhil Suganthan - muhilsuganthan@yourtpdc.com
 ** Backend programmer: Siva Subramanian - sivasubramanian@yourtpdc.com
 ** Last major Change: April 28,2016
 ** ********************************************************************
 ** *************************Powered By TPDC****************************
*/

include("config/config.php");
include("session.php");
?>



<!DOCTYPE html>
<html>

    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>:: CZAR ::</title>

        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

        <link href="css/animate.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">

    </head>

    <body class="gray-bg">

        <div class="middle-box text-center loginscreen  animated fadeInDown">
            <div>
                <div>
<h2 class="logo-name">Czar</h2>

            </div>
            <h3>Work smart, with Czar</h3>
            <!-- p 'error'is  used as the error message  display place in this page -->
            <p id="error">Enter your credentials</p>
            <form class="m-t" role="form" action="" method="post">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Username" required="" name="czar_user">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password" required="" name="czar_pwd">
                </div>
                <button type="submit" name="submit" class="btn btn-primary block full-width m-b">Login</button>

                <a href="#"><small>Forgot password?</small></a>
            </form>
            <p class="m-t"> <small>Powered By TPDC</small> </p>
        </div>
    </div>

        <!-- Mainly scripts -->
        <script src="js/jquery-2.1.1.js"></script>
        <script src="js/bootstrap.min.js"></script>

    </body>
</html>

<?php
if (isset($_POST['submit'])) {
    $usern = stripslashes($_POST['czar_user']);
    $pwd1 = stripslashes(($_POST['czar_pwd']));
    //$usern = mysqli_real_escape_string($usern);
    //$pwd2 = mysqli_real_escape_string($con,$pwd1);
    $pwd = sha1($pwd1);
    $sql_command="SELECT authority_level FROM cz_login WHERE login_user_id = '$usern' and login_passkey = '$pwd'";
    

    $result = mysqli_query($con,$sql_command);
    $rows = mysqli_num_rows($result);
    if ($rows == 1) {
        $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
        $privilege = $row['authority_level'];

        $_SESSION['user'] = $usern;
        $_SESSION['privilege'] = $privilege;
      //header('Location: result1.php');
      ?>
      <script>window.location = "result1.php"; </script>
      <?php
    } else {
        $error = "Username or Password is invalid";
        ?>
            <script type="text/javascript">
                var e = document.getElementById('error').innerHTML = "<font color='red'><b>Invalid Username or Password</font></b>";</script>
            <?php
        }
    }
 






