<?php
 header('Location: assets/index.php');