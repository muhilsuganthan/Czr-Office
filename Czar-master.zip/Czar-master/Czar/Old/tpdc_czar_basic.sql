-- phpMyAdmin SQL Dump
-- version 4.6.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 24, 2016 at 08:36 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tpdc_czar_basic`
--

-- --------------------------------------------------------

--
-- Table structure for table `cz_assets`
--

CREATE TABLE `cz_assets` (
  `assets_id` int(11) NOT NULL,
  `asset_name` varchar(32) NOT NULL,
  `asset_type` varchar(50) NOT NULL,
  `purchased_from` varchar(255) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `bought_date` varchar(32) NOT NULL,
  `status` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cz_assets`
--

INSERT INTO `cz_assets` (`assets_id`, `asset_name`, `asset_type`, `purchased_from`, `purpose`, `bought_date`, `status`) VALUES
(101, 'HP WorkStation', 'Computer', 'Modern Computers', 'Designing', '04/14/2016', 'Good');

-- --------------------------------------------------------

--
-- Table structure for table `cz_attendance`
--

CREATE TABLE `cz_attendance` (
  `id` int(11) NOT NULL,
  `attendance_id` varchar(32) NOT NULL,
  `attendance_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `attendance_place` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cz_department`
--

CREATE TABLE `cz_department` (
  `department_id` int(11) NOT NULL,
  `department_name` varchar(32) NOT NULL,
  `short_description` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cz_department`
--

INSERT INTO `cz_department` (`department_id`, `department_name`, `short_description`) VALUES
(101, 'Designing', 'Designing Department'),
(102, 'Quality Checking', 'QC department'),
(103, 'Management', ''),
(104, 'Finance', 'Finance team'),
(105, 'HR', 'human resource management '),
(106, 'Customer relation', 'CR team'),
(107, 'Marketing', 'Marketing team'),
(108, 'Sales team', 'Sales team'),
(109, 'Maintenance', 'Maintenance team'),
(110, 'Security', 'Office security'),
(111, 'Book Keeping', 'Book Keeping'),
(112, 'Legal department', 'Legal department for law management'),
(113, 'Administration', 'Administration Department'),
(114, 'Operational Department', 'Managing Operations of organizations');

-- --------------------------------------------------------

--
-- Table structure for table `cz_employee_details`
--

CREATE TABLE `cz_employee_details` (
  `employee_id` varchar(32) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `middle_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `father_name` varchar(30) DEFAULT NULL,
  `husband_name` varchar(30) DEFAULT NULL,
  `gender` varchar(15) NOT NULL,
  `marital_status` varchar(10) NOT NULL,
  `identity_mark` varchar(255) DEFAULT NULL,
  `caste` varchar(32) DEFAULT NULL,
  `religion` varchar(32) DEFAULT NULL,
  `blood_group` varchar(32) DEFAULT NULL,
  `date_of_birth` varchar(32) NOT NULL,
  `authority_level` int(11) NOT NULL,
  `post_title` varchar(32) NOT NULL,
  `joining_date` varchar(32) NOT NULL,
  `qualification` tinytext NOT NULL,
  `department` int(11) DEFAULT NULL,
  `phone_personal` bigint(20) DEFAULT NULL,
  `phone_work` bigint(20) DEFAULT NULL,
  `mobile_personal` bigint(20) NOT NULL,
  `mobile_work` bigint(20) NOT NULL,
  `email_personal` varchar(100) NOT NULL,
  `email_work` varchar(100) DEFAULT NULL,
  `is_active` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cz_employee_details`
--

INSERT INTO `cz_employee_details` (`employee_id`, `first_name`, `middle_name`, `last_name`, `father_name`, `husband_name`, `gender`, `marital_status`, `identity_mark`, `caste`, `religion`, `blood_group`, `date_of_birth`, `authority_level`, `post_title`, `joining_date`, `qualification`, `department`, `phone_personal`, `phone_work`, `mobile_personal`, `mobile_work`, `email_personal`, `email_work`, `is_active`) VALUES
('1542789451', 'SIva', NULL, 'Subramanian', NULL, NULL, '', '', NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', 1, 'HR Manager', '0000-00-00 00:00:00', 'MCA', 105, 987451, 987451, 9874562134, 0, 'sivasubramanian@yourtpdc.com', 'sivasubramanian@czar.com', 1),
('7845484', 'Gopal', '', 'mjnkj', 'kjnbkjn', '', 'Male', 'Single', 'nbmnb', 'mnb', 'mnb', 'mnb', '04/04/2016', 2, 'Administration', '04/06/2016', 'mnb mn', 103, 84767, 7678, 78678, 67687, 'mbvbm@bhh.hgb', 'hbh@hkh.hbhb', 1),
('9874512478', 'Muhil', NULL, 'Suganthan', NULL, NULL, '', '', NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', 2, 'Administration', '0000-00-00 00:00:00', 'MCA', 113, 654154, 654154, 9874512456, 0, 'zxv@dsv.jb', 'khb@khjb.jb', 1),
('admin', 'Geno', NULL, 'chrisvin', NULL, NULL, '', '', NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', 2, 'CEO', '0000-00-00 00:00:00', 'jhhbvjhv', 113, 87645221, 54684322, 35468465, 354231, 'khgkh@KJgk.khg', 'bgkhj@kjhgk.hjg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cz_employee_rating`
--

CREATE TABLE `cz_employee_rating` (
  `employee_Id` varchar(32) NOT NULL,
  `rating` varchar(5) NOT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cz_login`
--

CREATE TABLE `cz_login` (
  `id` int(11) NOT NULL,
  `login_user_id` varchar(32) NOT NULL,
  `login_passkey` varchar(255) NOT NULL,
  `authority_level` int(11) NOT NULL,
  `security_question` mediumtext,
  `answer` mediumtext,
  `SALT_key` varchar(32) DEFAULT NULL,
  `last_known_passkey` varchar(32) DEFAULT NULL,
  `is_active` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cz_login`
--

INSERT INTO `cz_login` (`id`, `login_user_id`, `login_passkey`, `authority_level`, `security_question`, `answer`, `SALT_key`, `last_known_passkey`, `is_active`) VALUES
(1, '1542789451', '8cb2237d0679ca88db6464eac60da96345513964', 1, 'jnb,jmnj', 'n ,jmn,jmn', NULL, '5f4dcc3b5aa765d61d8327deb882cf99', '1'),
(2, '9874512478', '5f4dcc3b5aa765d61d8327deb882cf99', 2, 'mnbmnb', 'mnbmb', NULL, '5f4dcc3b5aa765d61d8327deb882cf99', '1'),
(3, 'admin', '8cb2237d0679ca88db6464eac60da96345513964', 2, 'kn kn knkjnkjn', 'kjnkjnkjnkjnkj', NULL, '827ccb0eea8a706c4c34a16891f84e7b', '1'),
(7, '7845484', '88e2d8cd1e92fd5544c8621508cd706b', 2, NULL, NULL, NULL, '88e2d8cd1e92fd5544c8621508cd706b', '1'),
(8, '147854125478', '8cb2237d0679ca88db6464eac60da96345513964', 0, NULL, NULL, NULL, NULL, '1');

-- --------------------------------------------------------

--
-- Table structure for table `cz_login_log`
--

CREATE TABLE `cz_login_log` (
  `id` int(11) NOT NULL,
  `login_user_id` int(11) NOT NULL,
  `login_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `login_ip` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cz_message`
--

CREATE TABLE `cz_message` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(32) NOT NULL,
  `message` varchar(1000) DEFAULT NULL,
  `to_id` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cz_order_types`
--

CREATE TABLE `cz_order_types` (
  `id` int(11) NOT NULL,
  `order_type` varchar(15) DEFAULT NULL,
  `work_type` varchar(15) DEFAULT NULL,
  `color_type` varchar(15) DEFAULT NULL,
  `size_type` varchar(15) DEFAULT NULL,
  `output_type` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cz_order_types`
--

INSERT INTO `cz_order_types` (`id`, `order_type`, `work_type`, `color_type`, `size_type`, `output_type`) VALUES
(1, 'Overnight', NULL, NULL, NULL, ''),
(2, 'Rush', NULL, NULL, NULL, ''),
(3, 'Revision', NULL, NULL, NULL, ''),
(4, NULL, 'Print', NULL, NULL, ''),
(5, NULL, 'Digital', NULL, NULL, ''),
(6, NULL, NULL, 'Color', NULL, ''),
(7, NULL, NULL, 'BW', NULL, ''),
(8, NULL, NULL, NULL, 'Inches', ''),
(9, NULL, NULL, NULL, 'Feet', ''),
(10, NULL, NULL, NULL, NULL, 'Image'),
(11, NULL, NULL, NULL, NULL, 'PDF');

-- --------------------------------------------------------

--
-- Table structure for table `cz_posting_prvs`
--

CREATE TABLE `cz_posting_prvs` (
  `id` int(11) NOT NULL,
  `post_title` varchar(32) NOT NULL,
  `authority_level` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cz_posting_prvs`
--

INSERT INTO `cz_posting_prvs` (`id`, `post_title`, `authority_level`) VALUES
(1, 'Designer', 0),
(2, 'Quality Checking', 0),
(3, 'Marketing Manager', 1),
(4, 'General Manager', 1),
(5, 'HR Manager', 1),
(6, 'Finance Manager', 1),
(7, 'Senior Designer', 1),
(8, 'Senior Quality Tester', 1),
(9, 'Administration', 2),
(10, 'Book Keeper', 0),
(11, 'security', 0),
(12, 'Senior Security', 0),
(13, 'Marketing', 0),
(14, 'Sales', 0),
(15, 'customer relation Manager', 1),
(16, 'Customer support', 0),
(18, 'CEO', 2),
(19, 'COO', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cz_requirement_pool`
--

CREATE TABLE `cz_requirement_pool` (
  `employee_id` varchar(32) NOT NULL,
  `clent_name` varchar(50) NOT NULL,
  `client_id` varchar(32) NOT NULL,
  `job_id` varchar(32) NOT NULL,
  `client_organization` varchar(100) DEFAULT NULL,
  `client_email` varchar(100) DEFAULT NULL,
  `client_mobile` bigint(20) NOT NULL,
  `web_address` varchar(255) NOT NULL,
  `type_of_order` varchar(15) NOT NULL,
  `type_of_job` varchar(15) NOT NULL,
  `color_type` varchar(15) NOT NULL,
  `size_value` varchar(15) NOT NULL,
  `size_width` float NOT NULL,
  `size_height` float NOT NULL,
  `production_date` varchar(15) NOT NULL,
  `expected_date` varchar(15) NOT NULL,
  `instruction_file` varchar(255) NOT NULL,
  `output_type` varchar(15) NOT NULL,
  `job_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cz_teams`
--

CREATE TABLE `cz_teams` (
  `team_id` int(11) NOT NULL,
  `team_name` varchar(35) NOT NULL,
  `members_id` longtext NOT NULL,
  `leader_id` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cz_ticket_categories`
--

CREATE TABLE `cz_ticket_categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cz_ticket_pool`
--

CREATE TABLE `cz_ticket_pool` (
  `id` int(11) NOT NULL,
  `job_id` varchar(32) NOT NULL,
  `employee_id` varchar(32) NOT NULL,
  `commited_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `completed_time` datetime NOT NULL,
  `return_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cz_ticket_status`
--

CREATE TABLE `cz_ticket_status` (
  `id` int(11) NOT NULL,
  `job_status` varchar(15) NOT NULL,
  `job_status_value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cz_assets`
--
ALTER TABLE `cz_assets`
  ADD PRIMARY KEY (`assets_id`);

--
-- Indexes for table `cz_attendance`
--
ALTER TABLE `cz_attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cz_department`
--
ALTER TABLE `cz_department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `cz_employee_details`
--
ALTER TABLE `cz_employee_details`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `cz_employee_rating`
--
ALTER TABLE `cz_employee_rating`
  ADD UNIQUE KEY `employee_Id` (`employee_Id`);

--
-- Indexes for table `cz_login`
--
ALTER TABLE `cz_login`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login_user_id` (`login_user_id`);

--
-- Indexes for table `cz_login_log`
--
ALTER TABLE `cz_login_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cz_message`
--
ALTER TABLE `cz_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cz_order_types`
--
ALTER TABLE `cz_order_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cz_posting_prvs`
--
ALTER TABLE `cz_posting_prvs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cz_requirement_pool`
--
ALTER TABLE `cz_requirement_pool`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `cz_teams`
--
ALTER TABLE `cz_teams`
  ADD PRIMARY KEY (`team_id`);

--
-- Indexes for table `cz_ticket_categories`
--
ALTER TABLE `cz_ticket_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cz_ticket_pool`
--
ALTER TABLE `cz_ticket_pool`
  ADD PRIMARY KEY (`id`),
  ADD KEY `job_id` (`job_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `cz_ticket_status`
--
ALTER TABLE `cz_ticket_status`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cz_assets`
--
ALTER TABLE `cz_assets`
  MODIFY `assets_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;
--
-- AUTO_INCREMENT for table `cz_attendance`
--
ALTER TABLE `cz_attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cz_login`
--
ALTER TABLE `cz_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `cz_login_log`
--
ALTER TABLE `cz_login_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cz_message`
--
ALTER TABLE `cz_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cz_order_types`
--
ALTER TABLE `cz_order_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `cz_posting_prvs`
--
ALTER TABLE `cz_posting_prvs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `cz_ticket_categories`
--
ALTER TABLE `cz_ticket_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cz_ticket_pool`
--
ALTER TABLE `cz_ticket_pool`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cz_ticket_status`
--
ALTER TABLE `cz_ticket_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `cz_ticket_pool`
--
ALTER TABLE `cz_ticket_pool`
  ADD CONSTRAINT `cz_ticket_pool_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `cz_requirement_pool` (`job_id`),
  ADD CONSTRAINT `cz_ticket_pool_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `cz_employee_details` (`employee_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
