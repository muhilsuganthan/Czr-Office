<?php
/* 
 ** **************************Czar V 0.6****************************************
 ** ****************************************************************************
 ** 	Class holds functions required to register an employee
 **		empidgen()-> generates unique employee ID for the new employee
 **     empvalidate(accepts array)-> validates employee details
 **		
 ** 
 ** Backend programmer: Siva Subramanian - sivasubramanian@yourtpdc.com
 ** Created on June 7, 2016
 ** ****************************************************************************
 ** ****************************************************************************
*/

require_once 'dboperations.php';
require_once 'definitions.php';

class Employee{

	public function __construct(){

	}
	/*
	 	Returns Employee automatically generated employee ID
	 	@param $range gets range as input
	*/
	public function empidgen($length="6"){
		$gen_id = "";
		$characters = array_merge(range('1','9'));
		$max = count($characters)-1;
		for ($i = 0; $i < $length; $i++){
			$rand = mt_rand(0, $max);
			$gen_id .= $characters[$rand];
		}
		
        $row=$db->fetch_spl(TABLE_EMPREGISTER,"employee_id='$gen_id'");
        if(count($row)>0){
        	empidgen($length);
        }

        return $gen_id;
	}

	public function idgen($length="6"){

		$gen_id = "";
		$characters = array_merge(range('1','9'));
		$max = count($characters)-1;
		for ($i = 0; $i < $length; $i++){
			$rand = mt_rand(0, $max);
			$gen_id .= $characters[$rand];
		}
		$db=new DB();
        $row=$db->fetch_spl(TABLE_EMPREGISTER,"employee_id='$gen_id'",count(employee_id));
        if($row>0){
        	empidgen($length);
        }
		return $gen_id;
 	}
}