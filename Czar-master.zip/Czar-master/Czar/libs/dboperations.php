<?php

/* 
 ** **************************Czar V 0.6****************************************
 ** ****************************************************************************
 ** 	Class DB controls CRUD operations for all Modules
 **		insert(table_name,column_value array) -> insert new value in the Database
 **		delete(table_name,id) -> Deletes record from database
 **		update(table_name,column_name array,Value array) -> Updates Record
 ** Backend programmer: Siva Subramanian - sivasubramanian@yourtpdc.com
 ** Created on June 7, 2016
 ** ****************************************************************************
 ** ****************************************************************************
*/

class DB{

	public $con;
	/*
	 	Constructor for Assets Class. Establishes connection to the database
	*/
 	public function __construct(){
		define('DB_SERVER','localhost');
		define('DB_USER','yourtpdc_Czar');
		define('DB_PASSWORD','Fight_Club16');
		define('DB_NAME','yourtpdc_tpdc_czar_basic');
		$this->con = new mysqli(DB_SERVER,DB_USER,DB_PASSWORD);
		$this->con->select_db(DB_NAME);

		//Check Connection
		if($this->con->connect_errno){
			die("Connection Fail ".$this->con->connect_error);
		}
	}

	/*
 	 	Retrive data from database
 	 	@param $columns set to default value '*' accepts array of columns to look for
 	 	@return_value returns array of retrived data
 	*/
 	public function fetch($table_name,$columns="*"){

		$result=$this->con->query("SELECT $columns from $table_name");
		if($this->con->errno){
			die("Fail Select ".$this->con->error);
		}

		return $result->fetch_all(MYSQLI_ASSOC);
 	}

 
	/*
	  	Insert new data into the database
	  	@param $val_cols consists gets an array of column names and values
	 */ 
 	public function insert($table_name,array $val_cols){

 		$keysString = implode(", ", array_keys($val_cols));
		$i=0;
		echo "<br>";
		foreach($val_cols as $key=>$value) {
			$StValue[$i] = "'".$value."'";
		    $i++;
		}
		$StValues = implode(", ",array_values($StValue));
               
		if($this->con->query("INSERT INTO $table_name ($keysString) VALUES ($StValues)") === TRUE){
			$flag=true;
		}else{
			$flag=flase;
		}
		return $flag;
 	}

 	public function delete($table_name,$id){
  		if($this->con->query("DELETE FROM $table_name WHERE assets_id=".$id) === TRUE){
			$flag=true;
		}else{
			$flag=flase;
		}
		return $flag;
 	}

 	/*
 	 	Update existing values in the database
 	*/
	public function update($table_name,array $val_cols,array $values,$id){
  		for($i=0;$i<count($val_cols);$i++){
  			print_r($val_cols[$i]);print_r($values[$i]);echo"<br>"; echo $id;
  		if($this->con->query("UPDATE $table_name SET ".$val_cols[$i]."='".$values[$i]."' WHERE assets_id=".$id) === TRUE){
			$flag=true;
		}else{
			$flag=flase;
		}
		}
		return $flag;
 	}

 	public function fetch_spl($table_name,$condition,$columns="*"){

		$result=$this->con->query("SELECT $columns from $table_name WHERE $condition");
		if($this->con->errno){
			die("Fail Select ".$this->con->error);
		}

		return $result->fetch_all(MYSQLI_ASSOC);
 		
 	}
 	public function __destruct() {
		if($this->con){
			// Close the connection
        	$this->con->close();
        }	
	}
	
}