<?php

/* 
 ** **************************Czar V 0.6****************************************
 ** ****************************************************************************
 ** 	Consists of important definitions
 ** 
 ** Backend programmer: Siva Subramanian - sivasubramanian@yourtpdc.com
 ** Created on June 7, 2016
 ** ****************************************************************************
 ** ****************************************************************************
*/

define('DB_SERVER','localhost');
define('DB_USER','yourtpdc_Czar');
define('DB_PASSWORD','Fight_Club16');
define('DB_NAME','yourtpdc_tpdc_czar_basic');
define('TABLE_ASSETS','cz_assets');
define('TABLE_DEPARTMENT','cz_department');
define('TABLE_POSTING','cz_posting_prvs');
define('TABLE_EMPREGISTER','cz_employee_details');