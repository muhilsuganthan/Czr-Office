<?php
define('DB_SERVER','localhost');
define('DB_USER','yourtpdc_Czar');
define('DB_PASSWORD','Fight_Club16');
define('DB_NAME','yourtpdc_tpdc_czar_basic');

class DB_con
{
 function __construct()
 {
  $conn = mysqli_connect(DB_SERVER,DB_USER,DB_PASSWORD) or die('error connecting to server'.mysql_error());
  mysqli_select_db(DB_NAME, $conn) or die('error connecting to database->'.mysql_error());
 }
}

?>

