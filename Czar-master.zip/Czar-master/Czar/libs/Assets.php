<?php 
/* 
 ** **************************Czar V 0.6****************************************
 ** ****************************************************************************
 ** Assets class provides CRUD functionality to the ASSETS module
 ** 
 ** Backend programmer: Siva Subramanian - sivasubramanian@yourtpdc.com
 ** Created on June 7, 2016
 ** ****************************************************************************
 ** ****************************************************************************
*/

class Assets
{

	public $con;
	/*
	 	Constructor for Assets Class. Establishes connection to the database
	*/
 	public function __construct(){
		require_once 'dboperations.php';
		$con=$DB();
	}

 	/*
 	 	Closes the connection to the database
 	*/
 	public function __destruct(){
		if($this->con){
			// Close the connection
        	$this->con->close();
        }
	}

}