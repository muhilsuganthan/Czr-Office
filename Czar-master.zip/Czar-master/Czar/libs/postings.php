<?php 
/* 
 ** **************************Czar V 0.6****************************************
 ** ****************************************************************************
 ** Postings class provides CRUD functionality to the Department Module
 ** 
 ** Backend programmer: Siva Subramanian - sivasubramanian@yourtpdc.com
 ** Created on June 7, 2016
 ** ****************************************************************************
 ** ****************************************************************************
*/

class Posting
{

	public $con;
	/*
	 	Constructor for Posting Class. Establishes connection to the database
	*/
 	public function __construct(){
		require_once 'dboperations.php';
		$con=$DB();
	}

 	/*
 	 	Closes the connection to the database
 	*/
 	public function __destruct(){
		if($this->con){
			// Close the connection
        	$this->con->close();
        }
	}

}