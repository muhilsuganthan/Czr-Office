<?php
require_once 'definitions.php';
require_once 'employeeregister.php';
/*require_once 'dboperations.php'
require_once 'definitions.php';
$db= new DB();
//$row=$db->fetch();
//print_r($row);
$value = array("");
print_r($sql);
$value1= array("asset_name","purpose");
$value2= array("Imac+","Administration");
$row1=$Assets->update($value1,$value2,102);
print_r($row1);*/

$emp = new Employee();
$row1=$emp->empidgen();
echo $row1;
if($id==""){
	echo "hi";
}
else{
	echo "hello";
}