<?php
/* 
 ** **************************Czar V 0.4*********************************
 ** *********************************************************************
 ** result1.php decides the landing page for each user
 **
 ** Backend programmer: Siva Subramanian - sivasubramanian@yourtpdc.com
 ** ********************************************************************
 ** *************************Powered By TPDC****************************
*/

  session_start();
  $user= $_SESSION["user"];
  $prv= $_SESSION["privilege"];
     if($prv=="2")
	 {
	   header('Location: Admin/index.php'); 
	 }
	  elseif($prv=="1")
	  {
		  header('Location: Manager/index.php'); 
	  }
	  elseif($prv=="0")
	   {
		   header('Location: Employee/index.php'); 
		}
